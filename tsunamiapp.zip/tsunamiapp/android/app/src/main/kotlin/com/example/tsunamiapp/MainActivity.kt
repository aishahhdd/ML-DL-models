package com.example.tsunamiapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
