import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:getwidget/colors/gf_color.dart';
import 'package:getwidget/components/accordion/gf_accordion.dart';
import 'package:getwidget/components/appbar/gf_appbar.dart';
import 'package:getwidget/components/button/gf_button.dart';
import 'package:getwidget/components/button/gf_button_bar.dart';
import 'package:getwidget/components/button/gf_icon_button.dart';
import 'package:getwidget/components/card/gf_card.dart';
import 'package:getwidget/components/list_tile/gf_list_tile.dart';
import 'package:getwidget/components/tabs/gf_tabbar.dart';
import 'package:getwidget/components/tabs/gf_tabbar_view.dart';
import 'package:getwidget/components/typography/gf_typography.dart';
import 'package:getwidget/shape/gf_button_shape.dart';
import 'package:getwidget/types/gf_button_type.dart';
import 'package:getwidget/types/gf_typography_type.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:weather_icons/weather_icons.dart';
import 'firebase_options.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:http/http.dart' as http;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  if (Platform.isAndroid) {
    await AndroidInAppWebViewController.setWebContentsDebuggingEnabled(true);
  }

  runApp(const MyApp());
}

class MapUtils {
  MapUtils._();

  static Future<void> openMap(double latitude, double longitude) async {
    String googleUrl = 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
    if (await canLaunchUrl(Uri.parse(googleUrl))) {
      await launchUrl(Uri.parse(googleUrl));
    } else {
      throw 'Could not open the map.';
    }
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin {
  late TabController tabController;

  String url = "";
  double progress = 0;
  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;
  InAppWebViewGroupOptions options = InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: false,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
      ));

  var db = FirebaseFirestore.instance;
  var earthdata = [];
  var isNewTsunami = false;
  var indx = Random().nextInt(100);

  Future<List> getTodos() async {
    var snapshot = await db.collection('earthquakes').get();
    var docs = snapshot.docs;
    var datas = docs.map((e) => e.data()).toList();
    var qry = await fetchTsun({
      "long": datas[indx]["longitude"],
      "lat": datas[indx]["latitude"],
      "magnitude": datas[indx]["earthquakemgnt"],
      "intensity": datas[indx]["tsunaminten"],
      "housesdamaged": datas[indx]["housesdamaged"]
    });
    isNewTsunami = (qry);
    print(datas);
    return datas;
  }

  Future<bool> fetchTsun(data) async {
    print(data);
    final response = await http.post(
      Uri.parse('https://eo7tjoz1c8le7xu.m.pipedream.net'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );
    return jsonDecode(response.body)['isTsunami'];
  }

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Future<List> tvData = getTodos();

    return Scaffold(
      body: GFTabBarView(controller: tabController, children: <Widget>[
        SafeArea(
          child: FutureBuilder(
            future: tvData,
            builder: (ctx, snap) {
              if (snap.connectionState == ConnectionState.done && snap.data != null) {
                print("DTT");
                print(snap.data);
                List datasnap = snap.data!;
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      GFAppBar(
                        title: const Text("Beranda"),
                        centerTitle: true,
                        // actions: <Widget>[
                        //   GFIconButton(
                        //     icon: Icon(
                        //       Icons.favorite,
                        //       color: Colors.white,
                        //     ),
                        //     onPressed: () {},
                        //     type: GFButtonType.transparent,
                        //   ),
                        // ],
                      ),
                      const SizedBox(
                        //Use of SizedBox
                        height: 30,
                      ),
                      const Padding(
                        padding: EdgeInsets.fromLTRB(10, 0, 0, 0),
                        child: GFTypography(
                          text: 'Gempa Terkini',
                          type: GFTypographyType.typo4,
                        ),
                      ),
                      GFCard(
                        border: Border.all(),
                        boxFit: BoxFit.cover,
                        // title: GFListTile(
                        //   avatar: const Icon(WeatherIcons.earthquake,
                        //       color: Colors.red),
                        //   titleText: "${datasnap[0]["earthquakemgnt"]} SR",
                        // ),
                        content: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: <Widget>[
                                Column(
                                  children: [
                                    Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Icon(WeatherIcons.earthquake, color: Colors.red),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          Center(
                                            child: Text(
                                              "${datasnap[indx]["earthquakemgnt"].toStringAsFixed(1)} SR",
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(fontSize: 17),
                                            ),
                                          ),
                                        ]),
                                    const SizedBox(height: 10),
                                    const Text(
                                      "Magnitudo",
                                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  width: 10,
                                  height: MediaQuery.of(context).size.height * 0.1,
                                  child: Center(
                                    child: Container(
                                      width: 5,
                                      margin: const EdgeInsetsDirectional.only(top: 0, bottom: 0),
                                      decoration: const BoxDecoration(
                                          border: Border(
                                              right: BorderSide(width: 1, color: Colors.black))),
                                    ),
                                  ),
                                ),
                                Column(
                                  children: [
                                    Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          const Icon(WeatherIcons.tsunami,
                                              color: Color.fromRGBO(66, 165, 245, 1)),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          Center(
                                            child: Text(
                                              "${datasnap[indx]["tsunaminten"].toStringAsFixed(3)}",
                                              textAlign: TextAlign.center,
                                              style: const TextStyle(fontSize: 17),
                                            ),
                                          ),
                                        ]),
                                    const SizedBox(height: 10),
                                    const Text(
                                      "Tsunami Intensity",
                                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            GFButton(
                              onPressed: () {},
                              text:
                                  isNewTsunami ? "Berpotensi Tsunami" : "Tidak Berpotensi Tsunami",
                              shape: GFButtonShape.square,
                              color: isNewTsunami ? GFColors.DANGER : GFColors.PRIMARY,
                              fullWidthButton: true,
                            ),
                          ],
                        ),
                        buttonBar: GFButtonBar(
                          children: <Widget>[
                            GFButton(
                              onPressed: () {
                                MapUtils.openMap(
                                    datasnap[indx]['latitude'], datasnap[indx]['longitude']);
                              },
                              icon: const Icon(
                                Icons.location_on,
                                color: Colors.white,
                              ),
                              text: 'Location',
                              color: Colors.green,
                            ),
                            GFButton(
                                onPressed: () {},
                                icon: const Icon(Icons.share, color: Colors.white),
                                text: 'Share',
                                color: Colors.lightBlue),
                          ],
                        ),
                      ),
                      GFAccordion(
                          title: "Saat kamu melihat peringatan tsunami",
                          content: """1. Segera Menerima Peringatan:
   - Ketika menerima peringatan tsunami, segera perhatikan dan dengarkan informasi resmi dari sumber yang dapat dipercaya seperti otoritas pemerintah, stasiun televisi, atau sistem peringatan dini yang ada.
   - Jangan mengabaikan peringatan dan jangan menyebarkan informasi yang belum diverifikasi.

2. Tetap Tenang dan Jangan Panik:
   - Tetap tenang dan bantu tenangkan orang di sekitar Anda. Panik hanya akan menyulitkan proses evakuasi dan mengancam keselamatan diri sendiri dan orang lain.

3. Segera Evakuasi ke Tempat yang Aman:
   - Ketika ada peringatan tsunami, ikuti petunjuk evakuasi yang telah ditetapkan oleh pemerintah atau otoritas setempat.
   - Jika Anda berada di daerah pantai atau daerah rawan tsunami, segera evakuasi ke tempat yang tinggi dan jauh dari garis pantai.
   - Gunakan rute evakuasi yang telah ditetapkan dan hindari jalur yang berbahaya seperti jembatan, sungai, atau lereng curam.

4. Bawa Persediaan Darurat:
   - Siapkan tas atau kantong darurat yang berisi makanan ringan, air bersih, obat-obatan penting, pakaian ganti, peta daerah, senter, radio portabel, dan perlengkapan lain yang mungkin Anda butuhkan selama evakuasi.

5. Hindari Mendekati Pantai atau Wilayah Terdekat Air Laut:
   - Jauhi garis pantai dan wilayah air laut karena bisa terjadi gelombang pasca-tsunami yang berbahaya dan mematikan.
   - Jangan mencoba melihat tsunami atau mengambil foto/video karena dapat membahayakan keselamatan Anda.

6. Ikuti Instruksi dari Otoritas Setempat:
   - Patuhi petunjuk dari petugas keamanan atau otoritas setempat yang memberikan arahan dan bimbingan selama evakuasi atau proses penanggulangan bencana.
   - Jangan melakukan tindakan yang berisiko atau melanggar instruksi yang diberikan oleh otoritas.

7. Tetap Up-to-date dengan Informasi Terbaru:
   - Tetap terhubung dengan sumber informasi yang dapat dipercaya seperti radio, televisi, atau aplikasi resmi untuk mendapatkan pembaruan terbaru mengenai situasi dan instruksi evakuasi.

Ingatlah bahwa keselamatan adalah yang utama. Selalu mengutamakan langkah-langkah evakuasi dan instruksi dari otoritas setempat dalam menghadapi ancaman tsunami.
I"""),
                    ],
                  ),
                );
              } else {
                return const Center(child: CircularProgressIndicator());
              }
            },
          ),
        ),
        SafeArea(
          child: InAppWebView(
            key: webViewKey,
            initialUrlRequest: URLRequest(
                url: Uri.parse(
                    "https://web.powerva.microsoft.com/environments/Default-d7b95ec4-9a7f-4260-b2e3-eb53f0ac8401/bots/crdf2_tsunamiBot/webchat?__version__=2")),
            onWebViewCreated: (controller) {
              webViewController = controller;
            },
            androidOnPermissionRequest: (controller, origin, resources) async {
              return PermissionRequestResponse(
                  resources: resources, action: PermissionRequestResponseAction.GRANT);
            },
            onLoadStop: (controller, url) async {
              setState(() {
                this.url = url.toString();
              });
            },
            onProgressChanged: (controller, progress) {
              setState(() {
                this.progress = progress / 100;
              });
            },
            onConsoleMessage: (controller, consoleMessage) {
              print(consoleMessage);
            },
          ),
        )
      ]),
      bottomNavigationBar: GFTabBar(
        length: 2,
        controller: tabController,
        tabs: [
          const Tab(
            icon: Icon(Icons.home),
            child: Text(
              'Beranda',
            ),
          ),
          const Tab(icon: Icon(Icons.support_agent), child: Text('Bantuan')),
        ],
      ),
    );
  }
}
