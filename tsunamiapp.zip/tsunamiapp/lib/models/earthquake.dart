import 'dart:ffi';

class Earthquake {
  Double earthquakemgnt;
  Double housesdamaged;
  Double latitude;
  Double longitude;
  Double tsunaminten;

  Earthquake(this.earthquakemgnt, this.housesdamaged, this.latitude, this.longitude, this.tsunaminten);

  Earthquake.fromMap(Map<String, dynamic> map)
      : earthquakemgnt = map['earthquakemgnt'],
        housesdamaged = map['housesdamaged'],
        latitude = map['latitude'],
        longitude = map['longitude'],
        tsunaminten = map['tsunaminten'];

  Map<String, dynamic> toMap() {
    return {
      'earthquakemgnt': earthquakemgnt,
      'housesdamaged': housesdamaged,
      'latitude': latitude,
      'longitude': longitude,
      'tsunaminten': tsunaminten
    };
  }
}